%%Copyright (c) 2024,郑三棚，梁贵方
%Refering to S. Zheng, R. Feng, A. Huang, A modified moving least-squares suitable for scattered data fitting with outliers, J. Comput. Appl. Math. 370 (2020) 112655, doi:10.1016/j.cam.2019.112655.
classdef MMLSClass
     %本类使用于任意维度的数据，r为所输入权函数的半径，dp为多项式次数
     %Xn为所输入数据，其维度是是d*n，f为测试函数函数值n*1维。
     %pf为计算所得估计值
    properties(Access =private)
        n % 样本数量
        dp%d多项式的次数
        r % 半径
        f % 函数值
        d %维数
        Q % 基底的个数
        Xn%xy坐标
        Alpha
        pp % 基底值
        q %mmls权重
    end

    methods (Access = public)
        function obj = MMLSClass(r,dp,Xn,f)
            obj.r = r;
            obj.dp=dp;
            obj.f=f;
            obj.Xn=Xn;
            obj = obj.calculateBasisFunctions();
            %obj.q=w(obj.Xn(1,:),obj.Xn(2,:), obj.f');
            obj.q=w(obj.Xn, obj.f');

        end
        function pf= GetApproximationValue(obj,Yn)   
            [~,n1]=size(Yn);
            B=zeros(obj.Q,obj.n);
            pf = zeros(1, n1); % 预分配 pf 为 1 x n1 的数组
            for k = 1:n1
               A = 0; % 重置A为0
               B(:)=0;
                Y_k = Yn(1:obj.d, k); % 当前Y点
                for i = 1:obj.n
                    W = Ct(Y_k, obj.Xn(1:obj.d,i), obj.r);
                    if W~=0
                        A = A +obj.q(i)*  W * obj.pp(:, i) *obj.pp(:, i)';
                        B(:, i) = obj.q(i)* W *obj.pp(:, i);
                    else
                        A=A+0;
                    end
                end
               
            lambda = 1e-10;  % 正则化参数
            A = A + lambda * eye(size(A));  % 添加正则化项
            C = (A \ B) * obj.f; % 求解线性方程
            pf(k)= C'*PnByAlpha(Yn(:,k),obj.Alpha)'; % 计算更新后的函数值
            end  
        end


    end
    methods (Access = private)
        %计算基函数的数值
        function obj = calculateBasisFunctions(obj)
            [obj.d,obj.n]=size(obj.Xn);
            if obj.d==2
                [obj.Alpha,obj.Q] = PolyAlpha(obj.d,obj.dp);%使用的多项式基底指标;%2为元，obj.m为次数
                obj.pp=zeros(obj.Q,obj.n);
                for i=1:obj.n
                    obj.pp(:,i)=PnByAlpha(obj.Xn(:,i),obj.Alpha);
                end
            else
                error('所输入的数据维度不为2');
            end

        end


    end
end


function p=PnByAlpha(X,Alpha)
%PnByAlpha 在多指标集Alpha下多项式基底在X处的取值
%输出为行向量
[Q,d]=size(Alpha);
if length(X)~=d
    error('输入X错误')
else
    p=zeros(1,Q);
    x=X(:)';
    for i=1:Q
        p(i)=prod(x.^Alpha(i,:));
    end
end
end

function [A,Q] = PolyAlpha(d,m)
%PolyAlpha 根据输入返回总元次数不高于m的d元多项式的多指标集合
%   输入：d与m表示元数与次数
%   输出：A表示指标的集合，Q表示指标的个数，A是Q*d的
Q=nchoosek(d+m,d);
A=zeros(Q,d);
a=zeros(1,d);
i=2;
while i<=Q
    a=AddOne(a,m);%以m+1进制的形式使a增加1
    if sum(a)<=m
        A(i,:)=a;
        i=i+1;
    end
end
end
function b=AddOne(a,m)
N=length(a);
H=a(1);
if H>m
    error('不符合m+1近制，请检查程序')
else
    Ha=H+1;
    if Ha<m+1
        b=a;
        b(1)=Ha;
    else%需要近一位
        if N<=1
            %%不能增加
            error('增加溢出，请检查程序')
        else
            b=zeros(1,N);
            b(2:N)=AddOne(a(2:N),m);
        end
    end
end
end

function a = Ct(x, y, r)
% w - 移动最小二乘法中的权函数
% 输入:
%   x - 所求点（需要插值的点）
%   y - 数据点（用于插值的已知点）
%   r - 影响半径（影响权重的范围）
% 输出:
%   a - 权重值，根据 x 到 y 的距离和影响半径 r 计算得出

    % 计算距离的归一化值
    s = norm(x - y) / r;  % 这里计算 x 和 y 之间的欧几里得距离的归一化值

    % 根据 s 的值，选择不同的权重计算公式
    if (s <= 1/2)
        % 如果 s 小于等于 1/2，使用第一个权重计算公式
        a = 2/3 - 4 * s^2 + 4 * s^3;
    elseif (s <= 1)
        % 如果 s 在 (1/2, 1] 之间，使用第二个权重计算公式
        a = 4/3 - 4 * s + 4 * s^2 - (4/3) * s^3;
    else
        % 如果 s 大于 1，则权重为 0
        a = 0;
    end
end

% function q=w(x,y,f)
% %对权重进行一个挑选,最新版17/10/21修改了对于奇异值点权重的赋值
% n=length(x);
% TRI = delaunay(x,y);
% A=zeros(n,30);
% At=zeros(n,30);
% qq=zeros(1,n);
% for i=1:1:n
%     %c=[];
%     [a,~]=find(TRI==i);
%     al=length(a);
%     At(i,1)=al;
%     m = size(TRI(a(1),:), 2);
%     c_prealloc = NaN(al, m);
%     for j=1:1:al
%         %c=[c,TRI(a(j),:)];
%         c_prealloc(j, :) = TRI(a(j),:);
%         At(i,j+1)=a(j);
%     end
%     c = c_prealloc;
%     c=unique(c);
%     c(c==i)=[];
%     cl=length(c);
%     A(i,1)=cl;
%     for j=1:1:cl
%         A(i,j+1)=c(j);
%     end
%     if(A(i,1)>5)
%         df=zeros(A(i,1),1);
%         B=zeros(A(i,1),5);
%         %gg=zeros(5,1);
%         %k=zeros(2,1);
%         for j=1:1:A(i,1)
%             df(j)=f(c(j))-f(i);
%             dx=x(c(j))-x(i);
%             dy=y(c(j))-y(i);
%             B(j,:)=[dx,dy,0.5*dx^2,dx*dy,0.5*dy^2];
%         end
%         gg=(B'*B)\(B'*df);
%         k=[gg(1),gg(2)];
%     else
%         %ck=zeros(1,A(i,1)+1);
%         ck=[i,A(i,2:A(i,1)+1)];
%         xv=x(ck);yv=y(ck);
%         kc= convhull(xv,yv);
%         if(ismember(1,kc))
%             g=zeros(At(i,1),2);
%             gg=zeros(At(i,1),2);
%             s=zeros(At(i,1),2);
%             ss=zeros(At(i,1),2);
%             for j=1:1:At(i,1)
%                 a1=TRI(At(i,j+1),:);
%                 aa=setdiff(a1,i);
%                 [aaa,~]=find(TRI==aa(1));
%                 [aaaa,~]=find(TRI==aa(2));
%                 aaa=intersect(aaa,aaaa);
%                 aaa=setdiff(aaa,At(i,j+1));
%                 a2=TRI(aaa,:);
%                 b1=(y(a1(2))-y(a1(1)))*(f(a1(3))-f(a1(1)))-(y(a1(3))-y(a1(1)))*(f(a1(2))-f(a1(1)));
%                 b2=(x(a1(2))-x(a1(1)))*(f(a1(1))-f(a1(3)))-(x(a1(3))-x(a1(1)))*(f(a1(1))-f(a1(2)));
%                 b3=(x(a1(2))-x(a1(1)))*(y(a1(3))-y(a1(1)))-(x(a1(3))-x(a1(1)))*(y(a1(2))-y(a1(1)));
%                 bb1=(y(a2(2))-y(a2(1)))*(f(a2(3))-f(a2(1)))-(y(a2(3))-y(a2(1)))*(f(a2(2))-f(a2(1)));
%                 bb2=(x(a2(2))-x(a2(1)))*(f(a2(1))-f(a2(3)))-(x(a2(3))-x(a2(1)))*(f(a2(1))-f(a2(2)));
%                 bb3=(x(a2(2))-x(a2(1)))*(y(a2(3))-y(a2(1)))-(x(a2(3))-x(a2(1)))*(y(a2(2))-y(a2(1)));
%                 g(j,:)=[-b1/b3,-b2/b3];
%                 gg(j,:)=[-bb1/bb3,-bb2/bb3];
%                 s(j)=1/2*abs(b3);
%                 ss(j)=1/2*abs(bb3);
%             end
%             c1=zeros(1,2);
%             for j=1:1:At(i,1)
%                 c1=c1+1/s(j)*((2*s(j)+ss(j))*g(j,:)-s(j)*gg(j,:))*(1/(s(j)+ss(j)));
%             end
%             c2=0;
%             for j=1:1:At(i,1)
%                 c2=c2+1/s(j);
%             end
%             k=c1/c2;
%         else
%             g=zeros(A(i,1),2);
%             s=zeros(A(i,1),2);
%             for j=1:1:A(i,1)
%                 a1=TRI(At(i,j+1),:);
%                 b1=(y(a1(2))-y(a1(1)))*(f(a1(3))-f(a1(1)))-(y(a1(3))-y(a1(1)))*(f(a1(2))-f(a1(1)));
%                 b2=(x(a1(2))-x(a1(1)))*(f(a1(1))-f(a1(3)))-(x(a1(3))-x(a1(1)))*(f(a1(1))-f(a1(2)));
%                 b3=(x(a1(2))-x(a1(1)))*(y(a1(3))-y(a1(1)))-(x(a1(3))-x(a1(1)))*(y(a1(2))-y(a1(1)));
%                 g(j,:)=[-b1/b3,-b2/b3];
%                 s(j)=1/2*abs(b3);
%             end
%             c1=zeros(1,2);
%             for j=1:1:At(i,1)
%                 c1=c1+(1/s(j))*g(j,:);
%             end
%             c2=0;
%             for j=1:1:At(i,1)
%                 c2=c2+1/s(j);
%             end
%             k=c1/c2;
%         end
%     end
%     p=zeros(2,cl);
%     for j=1:1:A(i,1)
%         p(:,j)=[x(A(i,j+1));y(A(i,j+1))]-[x(i);y(i)];
%         df(j)=(f(A(i,j+1))-f(i))/norm(p(:,j));
%         p(:,j)=p(:,j)/norm(p(:,j));
%     end
%     kk=0;
%     for j=1:1:cl
%         kk=kk+abs(k*p(:,j)-df(j));
%     end
%     qq(i)=kk;
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% T=dfselect(qq);
% Tl=length(T);
% q=ones(1,n);
% for i=1:1:Tl
%     p=A(T(i),2:A(T(i),1)+1);
%     if(ismember(p,T))
%         q(T(i))=1/(1+qq(T(i)));
%     end
% end
% 
% end

function [A,B] = dfselect(q,Delta)
%通过一组数据每个之间的变化率，挑选出突变的部分
n=length(q);
[l,k]=sort(q);
d1=1;
d2=1;
i=1;
while(d2-d1<Delta &&i<n-1)
    i=i+1;
    d1=l(i)-l(i-1);
    d2=l(i+1)-l(i);
end
A=k(i+1:n);
B=k(1:i);
end


function q=w(X,f)
%对权重进行一个挑选,最新版17/10/21修改了对于奇异值点权重的赋值
n=length(X);
TRI = delaunay(X(1,:),X(2,:));%计算 Delaunay 三角剖分
A=zeros(n,30);
At=zeros(n,30);
qq=zeros(1,n);
for i=1:1:n
    %c=[];
    [a,~]=find(TRI==i);%储存第i个元素三角形的索引
    al=length(a);%参与三角形数量
    At(i,1)=al;%将 al（点 i 参与的三角形数量）存储到矩阵 At 的第 i 行的第一列中。At 矩阵用于记录每个点的相关信息，包括与其相邻的三角形的数量。
    m = size(TRI(a(1),:), 2);
    c_prealloc = NaN(al, m);
    for j=1:1:al
        %c=[c,TRI(a(j),:)];
        c_prealloc(j, :) = TRI(a(j),:);
        At(i,j+1)=a(j);
    end
    c = c_prealloc;
    c=unique(c);%N1表示包含与点 i 相关索引。包括i点
    c(c==i)=[]; % 从 N1 中去掉 i 点，得到 N
    cl=length(c);
    A(i,1)=cl;
    for j=1:1:cl
        A(i,j+1)=c(j);
    end
    if(A(i,1)>5)
        df=zeros(A(i,1),1);
        B=zeros(A(i,1),5);
        %gg=zeros(5,1);
        %k=zeros(2,1);
        for j=1:1:A(i,1)
            df(j)=f(c(j))-f(i);
            dx=X(1,c(j))-X(1,i);
            dy=X(2,c(j))-X(2,i);
            B(j,:)=[dx,dy,0.5*dx^2,dx*dy,0.5*dy^2];
        end
        gg=(B'*B)\(B'*df);
        k=[gg(1),gg(2)];
    else
        %ck=zeros(1,A(i,1)+1);
        ck=[i,A(i,2:A(i,1)+1)];%从矩阵 A中提出与i相关的邻接点索引
        xv=X(1,ck);yv=X(2,ck);
        kc= convhull(xv,yv);%接收xv和yv中的坐标，返回构成凸包的点的索引kc
        if(ismember(1,kc))
            g=zeros(At(i,1),2);
            gg=zeros(At(i,1),2);
            s=zeros(At(i,1),2);
            ss=zeros(At(i,1),2);
            for j=1:1:At(i,1)
                triangleVertices=TRI(At(i,j+1),:);%从 Delaunay 三角剖分 TRI 中获取第 j 个三角形的顶点索引 triangleVertices。
                otherVertices =setdiff(triangleVertices,i);%从三角形的顶点列表中去掉点 i，得到其他两个顶点的索引 otherVertices 。
                [connectedTriangles1,~]=find(TRI==otherVertices (1));
                [connectedTriangles2,~]=find(TRI==otherVertices (2));%找到 otherVertices (1) 和otherVertices (2) 这两个点在 TRI 中的索引位置，分别存储在 connectedTriangles1和 connectedTriangles2 中
                commonTriangles =intersect(connectedTriangles1,connectedTriangles2);%计算connectedTriangles1和 connectedTriangles2的交集，得到同时包含两个点的三角形索引。
                commonTriangles=setdiff(commonTriangles,At(i,j+1));%从 commonTriangles中去掉当前三角形的索引 At(i, j + 1)，以得到与当前三角形共享点的其他三角形索引。
                sharedTrianglesVertices=TRI(commonTriangles,:);%获取与当前三角形共享点的所有三角形的顶点索引。
                alpha=(X(2,triangleVertices(2))-X(2,triangleVertices(1)))*(f(triangleVertices(3))-f(triangleVertices(1)))-(X(2,triangleVertices(3))-X(2,triangleVertices(1)))*(f(triangleVertices(2))-f(triangleVertices(1)));
                beta=(X(1,triangleVertices(2))-X(1,triangleVertices(1)))*(f(triangleVertices(1))-f(triangleVertices(3)))-(X(1,triangleVertices(3))-X(1,triangleVertices(1)))*(f(triangleVertices(1))-f(triangleVertices(2)));
                gamma=(X(1,triangleVertices(2))-X(1,triangleVertices(1)))*(X(2,triangleVertices(3))-X(2,triangleVertices(1)))-(X(1,triangleVertices(3))-X(1,triangleVertices(1)))*(X(2,triangleVertices(2))-X(2,triangleVertices(1)));
                alpha1=(X(2,sharedTrianglesVertices(2))-X(2,sharedTrianglesVertices(1)))*(f(sharedTrianglesVertices(3))-f(sharedTrianglesVertices(1)))-(X(2,sharedTrianglesVertices(3))-X(2,sharedTrianglesVertices(1)))*(f(sharedTrianglesVertices(2))-f(sharedTrianglesVertices(1)));
                beta1=(X(1,sharedTrianglesVertices(2))-X(1,sharedTrianglesVertices(1)))*(f(sharedTrianglesVertices(1))-f(sharedTrianglesVertices(3)))-(X(2,sharedTrianglesVertices(3))-X(2,sharedTrianglesVertices(1)))*(f(sharedTrianglesVertices(1))-f(sharedTrianglesVertices(2)));
                gamma1=(X(1,sharedTrianglesVertices(2))-X(1,sharedTrianglesVertices(1)))*(X(2,sharedTrianglesVertices(3))-X(2,sharedTrianglesVertices(1)))-(X(1,sharedTrianglesVertices(3))-X(1,sharedTrianglesVertices(1)))*(X(2,sharedTrianglesVertices(2))-X(2,sharedTrianglesVertices(1)));
                g(j,:)=[-alpha/gamma,-beta/gamma];
                gg(j,:)=[-alpha1/gamma1,-beta1/gamma1];
                s(j)=1/2*abs(gamma);
                ss(j)=1/2*abs(gamma1);
            end
            c1=zeros(1,2);
            for j=1:1:At(i,1)
                c1=c1+1/s(j)*((2*s(j)+ss(j))*g(j,:)-s(j)*gg(j,:))*(1/(s(j)+ss(j)));
            end
            c2=0;
            for j=1:1:At(i,1)
                c2=c2+1/s(j);
            end
            k=c1/c2;
        else
            g=zeros(A(i,1),2);
            s=zeros(A(i,1),2);
            for j=1:1:A(i,1)
                triangleVertices=TRI(At(i,j+1),:);
                alpha2=(X(2,triangleVertices(2))-X(2,triangleVertices(1)))*(f(triangleVertices(3))-f(triangleVertices(1)))-(X(2,triangleVertices(3))-X(2,triangleVertices(1)))*(f(triangleVertices(2))-f(triangleVertices(1)));
                beta2=(X(1,triangleVertices(2))-X(1,triangleVertices(1)))*(f(triangleVertices(1))-f(triangleVertices(3)))-(X(1,triangleVertices(3))-X(1,triangleVertices(1)))*(f(triangleVertices(1))-f(triangleVertices(2)));
                gamma2=(X(1,triangleVertices(2))-X(1,triangleVertices(1)))*(X(2,triangleVertices(3))-X(2,triangleVertices(1)))-(X(1,triangleVertices(3))-X(1,triangleVertices(1)))*(X(2,triangleVertices(2))-X(2,triangleVertices(1)));
                g(j,:)=[-alpha2/gamma2,-beta2/gamma2];
                s(j)=1/2*abs(gamma2);
            end
            c1=zeros(1,2);
            for j=1:1:At(i,1)
                c1=c1+(1/s(j))*g(j,:);
            end
            c2=0;
            for j=1:1:At(i,1)
                c2=c2+1/s(j);
            end
            k=c1/c2;
        end
    end
    p=zeros(2,cl);
    for j=1:1:A(i,1)
        p(:,j)=[X(1,A(i,j+1));X(2,A(i,j+1))]-[X(1,i);X(2,i)];
        df(j)=(f(A(i,j+1))-f(i))/norm(p(:,j));
        p(:,j)=p(:,j)/norm(p(:,j));
    end
    kk=0;
    for j=1:1:cl
        kk=kk+abs(k*p(:,j)-df(j));
    end
    qq(i)=kk;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Delta=5;
I_O=dfselect(qq,Delta);
Tl=length(I_O);
q=ones(1,n);
for i=1:1:Tl
    p=A(I_O(i),2:A(I_O(i),1)+1);
    if(ismember(p,I_O))
        q(I_O(i))=1/(1+qq(I_O(i)));
    end
end

end




