%%Copyright (c) 2024,郑三棚，梁贵方
%Refering to H. Wendland, Scattered data approximation, Cambridge Monographs on Applied and Computational Mathematics, Cambridge University Press, Cambridge, 2004, doi:10.1017/cbo9780511617539.
classdef MLSClass
     %本类使用于任意维度的数据，r为所输入权函数的半径，dp为多项式次数
     %Xn为所输入数据，其维度是是d*n，f为测试函数函数值n*1维。
     %pf为计算所得估计值

    properties(Access =private)
        n  % 样本数量
        dp % d多项式的次数
        r  % 半径
        f  % 函数值
        d  % 维数
        Q  % 基底的个数
        Xn % xy坐标
        Alpha
        In % 符合条件的索引
        pp % 基底值
    end

    methods (Access = public)
        function obj = MLSClass(r,dp,Xn,f)
            obj.r = r;
            obj.dp=dp;
            obj.f=f;
            obj.Xn=Xn;
            obj = obj.calculateBasisFunctions();

        end
        function pf = GetApproximationValue(obj,Yn)
            [~,n1]=size(Yn);
            B=zeros(obj.Q,obj.n);
            pf = zeros(1, n1); % 预分配 pf 为 1 x n1 的数组
            for k = 1:n1
                A = 0; % 重置A为0
                B(:)=0;
                Y_k = Yn(1:obj.d, k); % 当前Y点
                for i = 1:obj.n
                    W = w(Y_k, obj.Xn(1:obj.d,i), obj.r);
                    if W~=0
                        A = A + W *obj.pp(:, i) *obj.pp(:, i)';
                        B(:, i) = W * obj.pp(:, i);
                    else
                        A=A+0;
                    end
                end
                lambda = 1e-10;  % 正则化参数
                A = A + lambda * eye(size(A));  % 添加正则化项
                C = (A \ B) * obj.f; % 求解线性方程
                pf(k) = C'*PnByAlpha(Yn(:,k),obj.Alpha)'; % 计算更新后的函数值
            end

        end
    end
    methods (Access = private)
        %计算基函数的数值
        function obj = calculateBasisFunctions(obj)
            [obj.d,obj.n]=size(obj.Xn);
            [obj.Alpha,obj.Q] = PolyAlpha(obj.d,obj.dp);%使用的多项式基底指标;
            obj.pp=zeros(obj.Q,obj.n);
            for i=1:obj.n
                obj.pp(:,i)=PnByAlpha(obj.Xn(:,i),obj.Alpha);
            end
        end
       

    end
end



function p=PnByAlpha(X,Alpha)
%PnByAlpha 在多指标集Alpha下多项式基底在X处的取值
%输出为行向量
[Q,d]=size(Alpha);
if length(X)~=d
    error('输入X错误')
else
    p=zeros(1,Q);
    x=X(:)';
    for i=1:Q
        p(i)=prod(x.^Alpha(i,:));
    end
end
end

function [A,Q] = PolyAlpha(d,m)
%PolyAlpha 根据输入返回总元次数不高于m的d元多项式的多指标集合
%   输入：d与m表示元数与次数
%   输出：A表示指标的集合，Q表示指标的个数，A是Q*d的
Q=nchoosek(d+m,d);
A=zeros(Q,d);
a=zeros(1,d);
i=2;
while i<=Q
    a=AddOne(a,m);%以m+1进制的形式使a增加1
    if sum(a)<=m
        A(i,:)=a;
        i=i+1;
    end
end
end
function b=AddOne(a,m)
N=length(a);
H=a(1);
if H>m
    error('不符合m+1近制，请检查程序')
else
    Ha=H+1;
    if Ha<m+1
        b=a;
        b(1)=Ha;
    else%需要近一位
        if N<=1
            %%不能增加
            error('增加溢出，请检查程序')
        else
            b=zeros(1,N);
            b(2:N)=AddOne(a(2:N),m);
        end
    end
end
end

function a = w(x, y, r)
% w - 移动最小二乘法中的权函数
% 输入:
%   x - 所求点（需要插值的点）
%   y - 数据点（用于插值的已知点）
%   r - 影响半径（影响权重的范围）
% 输出:
%   a - 权重值，根据 x 到 y 的距离和影响半径 r 计算得出

    % 计算距离的归一化值
    s = norm(x - y) / r;  % 这里计算 x 和 y 之间的欧几里得距离的归一化值

    if (s <= 1/2)
        % 如果 s 小于等于 1/2，使用第一个权重计算公式
        a = 2/3 - 4 * s^2 + 4 * s^3;
    elseif (s <= 1)
        % 如果 s 在 (1/2, 1] 之间，使用第二个权重计算公式
        a = 4/3 - 4 * s + 4 * s^2 - (4/3) * s^3;
    else
        % 如果 s 大于 1，则权重为 0
        a = 0;
    end
end







