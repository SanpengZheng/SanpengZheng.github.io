clear
%%
%通过MLH筛选并去除奇异值的算法
%%
% 参数设置
N=2000;
dp=3;
r=0.1;
e = 10^-3; % 收敛阈值         
d = 0.01;  % 计算用的小增量
d1=2;
%%
%采样数据点
Xn=Halton(N,d1);
%%
% 采样值
Fs=zeros(N,1);
f_test= @(x, y) 0.75 * exp(-((9 * x - 2).^2 + (9 * y - 2).^2) / 4) + ...
            0.75 * exp(-(9 * x + 1).^2 / 49 - (9 * y + 1) / 10) + ...
            0.5 * exp(-((9 * x - 7).^2 + (9 * y - 3).^2) / 4) - ...
            0.2 * exp(-(9 * x - 4).^2 - (9 * y - 7).^2);

for j=1:N
    Fs(j)=f_test(Xn(1,j),Xn(2,j));
end

%%
% 添加噪声
f=Fs;
% 设置离群点的数量
num_outliers = 20; % 你可以根据需要调整离群点的数量
% 随机选择离群点的索引
outlier_indices = randi(length(f), num_outliers, 1); % 随机生成离群点索引
% 生成随机的离群点值，范围在 [1, 2]
outlier_values = 1+rand(num_outliers, 1) * 1; % 在 [1, 2] 范围内生成离群点值
% 添加离群点到 ff
f(outlier_indices) = f(outlier_indices) + outlier_values;
% 提取离群点的坐标和对应的值
outlier_Xn = Xn(:, outlier_indices);
outlier_f = f(outlier_indices);
%% 
%设置网格
x_start =0; % x 的起始值
x_end = 1; % x 的结束值
num_points = 50; % 生成的点的数量

% 使用 linspace 生成均匀的 x 和 y 值
xx_filtered= linspace(x_start, x_end, num_points+2); % 生成 num_points 个均匀分布的点
yy_filtered = xx_filtered; % 令 yy 与 xx 相同
xx = xx_filtered(xx_filtered> 0 &xx_filtered < 1); % 过滤出所有大于 0 和小于 1 的值
yy=xx;
%%
test1=MLHClass(r,e,d,dp,Xn,f);
Pf=zeros(num_points,num_points);
for i=1:num_points
    for j=1:num_points
    Pf(i,j)=test1.GetApproximationValue([xx(i);yy(j)]);
    end
end
%%
%计算误差
Rv=zeros(num_points,num_points);
for i=1:num_points
    for j=1:num_points
    Rv(i,j)=f_test(xx(i),yy(j));
    end
end
 Pfe=test1.GetApproximationValue(Xn);
erros=abs(Fs'-Pfe);
%%
figure;
%画原始数据图像
subplot(2, 2, 1); % 2行2列的第一个位置
scatter3(outlier_Xn(1, :), outlier_Xn(2, :), outlier_f', 50, 'red', 'filled'); % 离群点 (红色)
hold on; % 使得后续绘图与当前图形叠加
scatter3(Xn(1, :), Xn(2, :), Fs, 20, 'blue', 'filled'); % 正常数据 (蓝色)
hold off;
title('原始数据');
%%
%画出原始的图像
subplot(2, 2, 2); % 2行2列的第一个位置
% 使用 surf 绘制曲面图
surf(xx, yy, Rv); % 绘制曲面
title('原始图');
%%
%画出拟合的图像
subplot(2, 2, 3); % 2行2列的第一个位置
% 使用 surf 绘制曲面图
surf(xx, yy,Pf); % 绘制曲面
title('拟合图');
%%
%画出误差的图像
subplot(2, 2, 4); % 2行2列的第一个位置 
x=1:N;
scatter(x, erros); % 'b-' 表示蓝色线，LineWidth 设置线宽
title('误差图');
%%

function Xn = Halton(N,d)
% 生成Halton点的函数,Halton(N,d)
% d表示Halton点的维数
% 使用matlab自带的haltonset生成点序列，然后使用matlab自带的net函数截取为可使用的散乱点
p=haltonset(d,'Skip',1e3,'Leap',1e2);%Skip=1e3即跳过序列的前1000个，Leap=1e2表示挑选点时是隔100个挑一个
D=net(p,N);
Xn=D';
end