%Copyright (c) 2024,郑三棚，梁贵方
%Refering toD. Levin, Between moving least-squares and moving least-ł1, BIT Numer. Math. 55 (3) (2014) 781–796, doi:10.1007/s10543-014- 0522-0.
classdef MLHClass
 %本类使用于任意维度的数据，r为所输入权函数的半径，e为迭代判断的精度，
 %d为计算用的小增量，dp为多项式的次数，Xn为所输入数据，其维度是是d*n，f为测试函数函数值n*1维。
 %pf为计算所得估计值

    properties(Access = private)
        n;              % 样本数量
        Xn;             % 所输入的数据集
        dp;             % 多项式的次数
        f;              % 函数值
        r;              % 权重函数的半径
        e;              % 精度
        d;              % 计算用的小增量 
        Alpha           % 矩阵指标集
        d1;             % 所输入数据的维度
        d2;             % 所需估计数组维度
        Q;              % 基底的个数
        c1;             % 系数 c1
        c2;             % 系数 c2
        z;              % 迭代计数器
        pp              % 基底值
    end

    methods(Access=public)
        function obj = MLHClass(r,e,d,dp,Xn,f)
            obj.r = r;
            obj.e = e;
            obj.d = d;
            obj.Xn= Xn;
            obj.f= f;
            obj.dp = dp;
            obj = obj.calculateBasisFunctions();
        end
       %运行MLH算法
        function pf =GetApproximationValue(obj,Yn)
            B = zeros(obj.Q, obj.n);
            [~,n1]=size(Yn);
            pf = zeros(1, n1); % 预分配 pf 为 1 x n1 的数组
            %W=zeros(1,n1);
            W_storage = zeros(obj.n, obj.n); % 创建一个 n x n 的矩阵用于存储 W
            for m=1:n1
                A = 0;
                B(:)=0;
                Y_k =Yn(1:obj.d1, m); % 当前Y点
                for i = 1:obj.n
                    W = w(Y_k, obj.Xn(1:obj.d1,i), obj.r);
                    W_storage(m, i) = W; % 存储 W
                    if W ~= 0
                        A = A + W * obj.pp(:,i) * obj.pp(:,i)';  % 权重矩阵
                        B(:, i) = W * obj.pp(:,i);  % 权重乘以基函数
                    else
                        A=A+0;
                    end
                end
                lambda = 1e-10;
                A = A + lambda * eye(size(A));  % 添加正则化项
                obj.c1 = (A \ B) * obj.f;
                h = obj.f' - obj.c1' * obj.pp;

                hh = obj.calculateNormalizedWeights(h, m,W_storage);
                dep = obj.calculateDependency( hh, h);
                obj.z(m) = 1; % 迭代计数器
                while norm(dep) >= obj.e && obj.z(m) <= 200
                    [A, b] = computeLinearSystem(obj, hh);
                    lambda = 1e-10;  % 正则化参数
                    A = A + lambda * eye(size(A));  % 添加正则化项
                    obj.c2 = A \ b; % 解线性方程
                    h = obj.f' - obj.c2' *obj. pp;

                    hh = obj.calculateNormalizedWeights(h, m,W_storage);

                    %dep = zeros(obj.Q, 1);
                    dep = obj.calculateDependency(hh, h);

                    obj.c1 = obj.c2; % 更新 c1 为当前 c2

                    obj.z(m) = obj.z(m) + 1; % 更新迭代次数
                end

                pf(m)= obj.c1' *PnByAlpha(Yn(:,m),obj.Alpha)'; % 计算最终函数值

            end

        end
    end
       methods(Access=private)
        %计算基函数的数值
        function obj = calculateBasisFunctions(obj)
            [obj.d1,obj.n]=size(obj.Xn);
            [obj.Alpha,obj.Q] = PolyAlpha(obj.d1,obj.dp);%使用的多项式基底指标;
            obj.pp=zeros(obj.Q,obj.n);
            for i=1:obj.n
                obj.pp(:,i)=PnByAlpha(obj.Xn(:,i),obj.Alpha);
            end
        end
        %计算归一化权重
        function hh = calculateNormalizedWeights(obj, h, m,W_storage)
            hh = zeros(1, obj.n);
            for i = 1:obj.n
                 W= W_storage(m, i);
                 hd=sqrt(h(i).^2+obj.d^2);
                 hh(i) =W/ hd;
            end
        end
        
        function [A, b] = computeLinearSystem(obj, hh)
            % 预分配矩阵
            A = zeros(obj.Q);
            b = zeros(obj.Q, 1);

            % 使用向量化计算b
            for k = 1:obj.Q
                b(k) = sum(obj.f' .* obj.pp(k, :) .* hh); % 向量化
            end

            % 计算 A 矩阵
            for k = 1:obj.Q
                for j = k:obj.Q
                    A(k, j) = sum(obj.pp(k, :) .* obj.pp(j, :) .* hh); % 向量化
                    A(j, k) = A(k, j); % 利用对称性
                end
            end
        end


    
        %计算依赖性
        function dep = calculateDependency(obj, hh, h) 
           dep = sum(hh .* (-h) .* obj.pp, 2); 
        end

end
end

function p=PnByAlpha(X,Alpha)
%PnByAlpha 在多指标集Alpha下多项式基底在X处的取值
%输出为行向量
[Q,d]=size(Alpha);
if length(X)~=d
    error('输入X错误')
else
    p=zeros(1,Q);
    x=X(:)';
    for i=1:Q
        p(i)=prod(x.^Alpha(i,:));
    end
end
end

%多项式计算函数
function [A,Q] = PolyAlpha(d,m)
%PolyAlpha 根据输入返回总元次数不高于m的d元多项式的多指标集合
%   输入：d与m表示元数与次数
%   输出：A表示指标的集合，Q表示指标的个数，A是Q*d的
Q=nchoosek(d+m,d);
A=zeros(Q,d);
a=zeros(1,d);
i=2;
while i<=Q
    a=AddOne(a,m);%以m+1进制的形式使a增加1
    if sum(a)<=m
        A(i,:)=a;
        i=i+1;
    end
end
end
function b=AddOne(a,m)
N=length(a);
H=a(1);
if H>m
    error('不符合m+1近制，请检查程序')
else
    Ha=H+1;
    if Ha<m+1
        b=a;
        b(1)=Ha;
    else%需要近一位
        if N<=1
            %%不能增加
            error('增加溢出，请检查程序')
        else
            b=zeros(1,N);
            b(2:N)=AddOne(a(2:N),m);
        end
    end
end
end


%权重函数
function a = w(x, y, r)
% w - 移动最小二乘法中的权函数
% 输入:
%   x - 所求点（需要插值的点）
%   y - 数据点（用于插值的已知点）
%   r - 影响半径（影响权重的范围）
% 输出:
%   a - 权重值，根据 x 到 y 的距离和影响半径 r 计算得出

    % 计算距离的归一化值
    s = norm(x - y) / r;  % 这里计算 x 和 y 之间的欧几里得距离的归一化值

   if (s <= 1/2)
        % 如果 s 小于等于 1/2，使用第一个权重计算公式
        a = 2/3 - 4 * s^2 + 4 * s^3;
    elseif (s <= 1)
        % 如果 s 在 (1/2, 1] 之间，使用第二个权重计算公式
        a = 4/3 - 4 * s + 4 * s^2 - (4/3) * s^3;
    else
        % 如果 s 大于 1，则权重为 0
        a = 0;
    end
end

% function hd= hd(x,d)
% %MLH中的Hd函数
% hd=sqrt(x.^2+d^2);
% end
